# PALASH Speech Latency Report

## Test 1

Hindi Input:
आज हम गिनती सीखेंगे

ASR:
4658.85 ms

Translation:
4662.09 ms

TTS:
2514.84 ms

Total:
39321.39 ms

Result:
PASS
TEST 2

Hindi Input:
राम स्कूल जाता है

ASR Output:
राम स्कूल जाता है

Santali Output:
ᱨᱟᱢ ᱵᱤᱨᱫᱟᱹᱜᱟᱲ ᱮ ᱥᱮᱱ ᱞᱮᱱᱟ ᱾

ASR Latency:
4337.17 ms

Translation Latency:
3067.70 ms

TTS Latency:
2602.31 ms

Total Latency:
31120.55 ms

Result:
PASS
TEST 3

Hindi Input:
बैठ जाइए

ASR Output:
बेट जाएए

Santali Output:
ᱵᱮᱹᱴ ᱪᱟᱞᱟᱣ ᱢᱮ ᱾

ASR Latency:
4191.46 ms

Translation Latency:
3948.09 ms

TTS Latency:
1877.42 ms

Total Latency:
73965.64 ms

Result:
PASS (ASR Misrecognition)