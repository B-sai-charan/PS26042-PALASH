# PALASH — M5 Educational Content Package

## Overview

This repository contains the educational content package prepared for the PALASH project.

PALASH is an offline-first educational learning system designed to support bilingual classroom learning through:

- Hindi educational content
- Santali / Ol Chiki learning support
- Lesson content
- Worksheets
- Flashcards
- Assessments
- Santali audio assets
- Structured JSON and CSV datasets

The purpose of this package is to provide machine-readable educational content that can be integrated into the PALASH Android application.

---

# Educational Scope

## Grade 2

Subject:

Mathematics

Primary Topic:

Counting and Numbers

The Grade 2 content includes:

- Lesson content
- Number vocabulary
- Santali learning text
- Lesson audio
- Worksheets
- Flashcards
- Assessments
- Reusable number audio

The Grade 2 learning experience focuses on:

- Number recognition
- Counting objects
- Reading numbers
- Matching numbers with words
- Basic number understanding

The Grade 2 lesson implementation includes bilingual Hindi and Santali content together with number-based learning activities. :contentReference[oaicite:1]{index=1}

---

# Grade 3

Subject:

Mathematics

Topic:

Counting and Number Learning

The Grade 3 content package includes:

- Lesson content
- Worksheets
- Flashcards
- Assessments
- Santali / Ol Chiki text
- Audio mappings
- HTML preview generation

Grade 3 content is structured independently from Grade 2 so that both grades can be integrated separately into the Android application.

---

# Project Structure

```text
M5_handover/
│
├── audio/
│   └── santali_audio/
│       │
│       ├── numbers/
│       │
│       ├── lesson_g2/
│       │
│       ├── worksheet/
│       │
│       ├── flashcards/
│       │
│       ├── assessment/
│       │
│       ├── lesson_g3/
│       │
│       ├── worksheet_g3/
│       │
│       ├── flashcards_g3/
│       │
│       └── assessment_g3/
│
├── data/
│   │
│   ├── Grade 2 JSON files
│   ├── Grade 3 JSON files
│   ├── CSV content files
│   └── Audio/content mapping data
│
├── src/
│   │
│   ├── Grade 2 generators
│   ├── Grade 3 generators
│   ├── Lesson generators
│   ├── Worksheet generators
│   ├── Flashcard generators
│   └── Assessment generators
│
├── output/
│   │
│   ├── Grade 2 HTML previews
│   ├── Grade 3 HTML previews
│   ├── Lesson previews
│   ├── Worksheet previews
│   ├── Flashcard previews
│   └── Assessment previews
│
└── README.md