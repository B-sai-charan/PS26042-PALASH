import json
from pathlib import Path


# ==================================================
# PATH CONFIGURATION
# ==================================================

BASE_DIR = Path(__file__).resolve().parent.parent

INPUT_FILE = BASE_DIR / "data" / "assessments_g3_counting.json"

OUTPUT_DIR = BASE_DIR / "output"

OUTPUT_FILE = OUTPUT_DIR / "assessments_g3_counting.html"

OUTPUT_DIR.mkdir(exist_ok=True)


# ==================================================
# LOAD ASSESSMENT DATA
# ==================================================

if not INPUT_FILE.exists():
    raise FileNotFoundError(
        f"Assessment JSON file not found:\n{INPUT_FILE}"
    )


with open(
    INPUT_FILE,
    "r",
    encoding="utf-8"
) as file:

    assessment = json.load(file)


# ==================================================
# AUDIO PATH CONFIGURATION
# ==================================================

ASSESSMENT_AUDIO_DIR = (
    BASE_DIR
    / "audio"
    / "santali_audio"
    / "assessment_g3"
)


NUMBER_AUDIO_DIR = (
    BASE_DIR
    / "audio"
    / "santali_audio"
    / "numbers"
)


# ==================================================
# OPTION AUDIO MAPPING
# ==================================================

def option_audio_path(option):
    """
    Maps numeric options to their respective audio files.

    Example:
    Option:
        16

    Expected audio:
        ../audio/santali_audio/numbers/number_16.wav
    """

    value = str(option).strip()

    if value.isdigit():

        return (
            "../audio/"
            "santali_audio/"
            "numbers/"
            f"number_{value}.wav"
        )

    return ""


# ==================================================
# QUESTION AUDIO MAPPING
# ==================================================

def question_audio_path(question_id):
    """
    Maps question ID to Grade 3 assessment audio.

    Example:
        ASG301

    Expected file:
        ../audio/santali_audio/assessment_g3/ASG301.wav
    """

    return (
        "../audio/"
        "santali_audio/"
        "assessment_g3/"
        f"{question_id}.wav"
    )


# ==================================================
# OPTIONAL PYTHON AUDIO VALIDATION
# ==================================================

print("\n==========================================")
print("GRADE 3 ASSESSMENT AUDIO VALIDATION")
print("==========================================\n")


for question in assessment.get("questions", []):

    qid = str(
        question.get("question_id", "")
    ).strip()

    if qid:

        question_audio_file = (
            ASSESSMENT_AUDIO_DIR
            / f"{qid}.wav"
        )

        if question_audio_file.exists():

            print(
                f"✓ Question audio found: "
                f"{question_audio_file.name}"
            )

        else:

            print(
                f"⚠ Question audio missing: "
                f"{question_audio_file}"
            )


    for option in question.get("options", []):

        value = str(option).strip()

        if value.isdigit():

            option_audio_file = (
                NUMBER_AUDIO_DIR
                / f"number_{value}.wav"
            )

            if option_audio_file.exists():

                print(
                    f"✓ Option audio found: "
                    f"{option_audio_file.name}"
                )

            else:

                print(
                    f"⚠ Option audio missing: "
                    f"{option_audio_file}"
                )


print("\n==========================================\n")


# ==================================================
# HTML START
# ==================================================

html = """
<!DOCTYPE html>

<html lang="hi">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>पलाश - Grade 3 Assessment</title>


<style>


body {

    font-family:
        Arial,
        sans-serif;

    margin: 0;

    padding: 20px;

    background:
        #f5f5f5;

}


.container {

    max-width:
        1100px;

    margin:
        auto;

}


.question {

    background:
        white;

    border:
        1px solid #999;

    border-radius:
        12px;

    padding:
        25px;

    margin-bottom:
        25px;

}


.hindi {

    font-size:
        26px;

    font-weight:
        bold;

    margin-bottom:
        10px;

}


.santali {

    font-size:
        24px;

    margin-bottom:
        15px;

}


.option-row {

    display:
        flex;

    align-items:
        center;

    gap:
        10px;

    margin:
        10px 0;

}


.option {

    flex:
        1;

    display:
        flex;

    align-items:
        center;

    gap:
        10px;

    padding:
        15px;

    border:
        1px solid #aaa;

    border-radius:
        8px;

    cursor:
        pointer;

}


.audio-button {

    padding:
        8px 12px;

    font-size:
        18px;

    border:
        1px solid #777;

    border-radius:
        8px;

    background:
        white;

    cursor:
        pointer;

    flex-shrink:
        0;

}


.audio-button:hover {

    background:
        #eeeeee;

}


.check-button {

    padding:
        14px 30px;

    font-size:
        20px;

    cursor:
        pointer;

    border:
        none;

    border-radius:
        8px;

}


.correct-answer {

    border:
        2px solid green;

    background:
        rgba(0, 128, 0, 0.15);

}


.wrong {

    border:
        2px solid red;

    background:
        rgba(255, 0, 0, 0.15);

}


.unanswered {

    background-color:
        #eeeeee;

}


.result {

    margin-top:
        20px;

    font-size:
        24px;

    font-weight:
        bold;

}


</style>

</head>


<body>


<div class="container">


<h1>पलाश 🌸</h1>


<div>

ᱯᱟᱞᱟᱥ

</div>


<hr>


"""


# ==================================================
# GENERATE QUESTIONS
# ==================================================

for index, q in enumerate(
    assessment.get("questions", []),
    start=1
):

    qid = str(
        q.get("question_id", "")
    ).strip()


    hindi_text = q.get(
        "hindi_text",
        q.get(
            "question",
            ""
        )
    )


    santali_text = q.get(
        "santali_text",
        ""
    )


    question_text = q.get(
        "question",
        ""
    )


    question_audio = question_audio_path(
        qid
    )


    html += f"""
<div class="question">


<h3>

Question {index}

</h3>


<div class="hindi">

{hindi_text}

</div>


<div class="santali">

{santali_text}

</div>


<button
type="button"
class="audio-button"
onclick="playAudio('{question_audio}')"
title="Play question audio"
>

🔊

</button>


<p>

<b>

{question_text}

</b>

</p>

"""


    # ==============================================
    # OPTIONS + RESPECTIVE AUDIO
    # ==============================================

    for option in q.get(
        "options",
        []
    ):

        option_value = str(
            option
        ).strip()


        audio_path = option_audio_path(
            option_value
        )


        audio_button = ""


        if audio_path:

            audio_button = f"""
<button
type="button"
class="audio-button"
onclick="playAudio('{audio_path}')"
title="Play option audio"
>

🔊

</button>
"""


        html += f"""
<div class="option-row">


<label class="option">


<input
type="radio"
name="{qid}"
value="{option_value}"
>


<span>

{option_value}

</span>


</label>


{audio_button}


</div>

"""


    html += """

</div>

"""


# ==================================================
# ANSWER KEY
# ==================================================

answers = {

    str(
        q.get(
            "question_id",
            ""
        )
    ): str(
        q.get(
            "correct_answer",
            ""
        )
    )

    for q in assessment.get(
        "questions",
        []
    )

}


# ==================================================
# JAVASCRIPT
# ==================================================

html += f"""


<button
type="button"
class="check-button"
onclick="checkAnswers()"
>

उत्तर जमा करें ✅

</button>


<div
id="result"
class="result"
>

</div>


<script>


const answers =

{json.dumps(
    answers,
    ensure_ascii=False
)};


let currentAudio = null;



// ================================================
// PLAY AUDIO
// ================================================

function playAudio(path) {{

    console.log(
        "Attempting to play audio:",
        path
    );


    if (!path) {{

        console.error(
            "No audio path provided."
        );

        alert(
            "ऑडियो फ़ाइल उपलब्ध नहीं है।"
        );

        return;

    }}


    if (currentAudio) {{

        currentAudio.pause();

        currentAudio.currentTime = 0;

    }}


    currentAudio = new Audio(path);


    currentAudio.addEventListener(
        "error",
        function() {{

            console.error(
                "Audio could not be loaded:",
                path
            );


            alert(
                "ऑडियो फ़ाइल लोड नहीं हो सकी।\\n\\n" +
                "Path: " +
                path
            );

        }}
    );


    currentAudio.play().catch(
        function(error) {{

            console.error(
                "Audio playback error:",
                error
            );


            alert(
                "ऑडियो चलाने में समस्या हुई।"
            );

        }}
    );

}}



// ================================================
// CHECK ANSWERS
// ================================================

function checkAnswers() {{

    let score = 0;


    const total =

        Object.keys(
            answers
        ).length;


    for (

        const questionId
        in
        answers

    ) {{


        const correctAnswer =

            answers[
                questionId
            ];


        const allOptions =

            document.querySelectorAll(

                `input[name="${{questionId}}"]`

            );


        const selected =

            document.querySelector(

                `input[name="${{questionId}}"]:checked`

            );


        allOptions.forEach(

            option => {{


                const label =

                    option.parentElement;


                label.classList.remove(

                    "correct-answer",

                    "wrong",

                    "unanswered"

                );


                if (

                    option.value ===
                    correctAnswer

                ) {{

                    label.classList.add(

                        "correct-answer"

                    );

                }}


                else if (

                    option.checked

                ) {{

                    label.classList.add(

                        "wrong"

                    );

                }}


                else {{

                    label.classList.add(

                        "unanswered"

                    );

                }}

            }}

        );


        if (

            selected &&

            selected.value ===
            correctAnswer

        ) {{

            score++;

        }}

    }}


    const percentage =

        total > 0

        ?

        Math.round(

            (score / total) * 100

        )

        :

        0;


    document

        .getElementById(
            "result"
        )

        .innerHTML =

        `स्कोर: ${{score}} / ${{total}}
        (${{percentage}}%)`;

}}


</script>


</div>


</body>


</html>

"""


# ==================================================
# SAVE HTML
# ==================================================

OUTPUT_FILE.write_text(

    html,

    encoding="utf-8"

)


print(
    "=========================================="
)

print(
    "Assessment generated successfully!"
)

print(
    f"Saved to: {OUTPUT_FILE}"
)

print(
    "=========================================="
)