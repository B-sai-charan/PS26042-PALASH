package com.sih2026.palash.audio

import android.content.Context
import android.util.Log

/**
 * Data model for Santali Audio Metadata as defined in the M3 manifest.
 * Facts: 22050 Hz, mono, 16-bit PCM, pyttsx3-generated, validation_status = UNVERIFIED.
 */
data class SantaliAudioMetadata(
    val audioId: String,
    val relativeAssetPath: String,
    val category: String,
    val grade: Int = 2,
    val sampleRate: Int = 22050,
    val channels: Int = 1,
    val bitsPerSample: Int = 16,
    val generationMethod: String = "pyttsx3-generated",
    val validationStatus: String = "UNVERIFIED"
)

/**
 * Clean abstraction for resolving and verifying Santali audio assets bundled in assets.
 */
interface SantaliAudioRepository {
    fun getAudioMetadata(audioId: String): SantaliAudioMetadata?
    fun getAssetPathForAudio(audioId: String): String?
    fun hasAudioAsset(audioId: String): Boolean
    fun listGrade2AudioAssets(): List<SantaliAudioMetadata>
}

class SantaliAudioRepositoryImpl(
    private val context: Context
) : SantaliAudioRepository {

    companion object {
        private const val TAG = "SantaliAudioRepository"
        private const val BASE_ASSET_DIR = "audio/santali/g2_counting"
    }

    private val assetMap = mutableMapOf<String, SantaliAudioMetadata>()

    init {
        scanAssets()
    }

    private fun scanAssets() {
        val categories = listOf("numbers", "worksheet", "flashcards", "assessment")
        for (category in categories) {
            val dirPath = "$BASE_ASSET_DIR/$category"
            try {
                val files = context.assets.list(dirPath) ?: emptyArray()
                for (file in files) {
                    if (file.endsWith(".wav")) {
                        val audioId = file.removeSuffix(".wav")
                        val fullAssetPath = "$dirPath/$file"
                        val meta = SantaliAudioMetadata(
                            audioId = audioId,
                            relativeAssetPath = fullAssetPath,
                            category = category,
                            grade = 2,
                            sampleRate = 22050,
                            channels = 1,
                            bitsPerSample = 16,
                            generationMethod = "pyttsx3-generated",
                            validationStatus = "UNVERIFIED"
                        )
                        assetMap[audioId] = meta
                        assetMap[file] = meta // Also map exact filename
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not list assets in $dirPath: ${e.message}")
            }
        }
        Log.i(TAG, "Indexed ${assetMap.size} Grade-2 Santali audio assets.")
    }

    override fun getAudioMetadata(audioId: String): SantaliAudioMetadata? {
        return assetMap[audioId]
    }

    override fun getAssetPathForAudio(audioId: String): String? {
        return assetMap[audioId]?.relativeAssetPath
    }

    override fun hasAudioAsset(audioId: String): Boolean {
        val path = getAssetPathForAudio(audioId) ?: return false
        return try {
            val afd = context.assets.openFd(path)
            afd.close()
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun listGrade2AudioAssets(): List<SantaliAudioMetadata> {
        return assetMap.values.distinctBy { it.audioId }
    }
}
