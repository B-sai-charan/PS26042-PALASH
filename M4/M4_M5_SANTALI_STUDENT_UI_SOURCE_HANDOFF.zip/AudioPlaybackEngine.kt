package com.sih2026.palash.audio

import android.content.Context
import android.media.MediaPlayer
import android.util.Log

enum class AudioPlaybackState {
    IDLE,
    LOADING,
    PLAYING,
    COMPLETED,
    ERROR
}

interface AudioPlaybackEngine {
    val currentState: AudioPlaybackState
    fun playAsset(assetPath: String, onStateChanged: (AudioPlaybackState, String?) -> Unit)
    fun stop()
    fun release()
}

class AndroidAudioPlaybackEngineImpl(
    private val context: Context
) : AudioPlaybackEngine {

    companion object {
        private const val TAG = "AudioPlaybackEngine"
    }

    private var mediaPlayer: MediaPlayer? = null
    private var _currentState: AudioPlaybackState = AudioPlaybackState.IDLE
    override val currentState: AudioPlaybackState get() = _currentState

    private var listener: ((AudioPlaybackState, String?) -> Unit)? = null

    @Synchronized
    override fun playAsset(assetPath: String, onStateChanged: (AudioPlaybackState, String?) -> Unit) {
        stopInternal()

        this.listener = onStateChanged
        updateState(AudioPlaybackState.LOADING, null)

        try {
            val afd = context.assets.openFd(assetPath)
            val player = MediaPlayer()
            this.mediaPlayer = player

            player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()

            player.setOnPreparedListener { mp ->
                if (_currentState == AudioPlaybackState.LOADING && mediaPlayer == mp) {
                    updateState(AudioPlaybackState.PLAYING, null)
                    mp.start()
                }
            }

            player.setOnCompletionListener { mp ->
                if (mediaPlayer == mp) {
                    updateState(AudioPlaybackState.COMPLETED, null)
                    stopInternal()
                }
            }

            player.setOnErrorListener { mp, what, extra ->
                Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
                val errorMsg = "Audio playback error (what: $what, extra: $extra)"
                updateState(AudioPlaybackState.ERROR, errorMsg)
                stopInternal()
                true
            }

            player.prepareAsync()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open or prepare asset WAV: ${e.message}", e)
            updateState(AudioPlaybackState.ERROR, "Failed to load audio asset: ${e.localizedMessage}")
            stopInternal()
        }
    }

    @Synchronized
    override fun stop() {
        stopInternal()
        updateState(AudioPlaybackState.IDLE, null)
    }

    @Synchronized
    override fun release() {
        stopInternal()
        listener = null
        updateState(AudioPlaybackState.IDLE, null)
    }

    private fun stopInternal() {
        mediaPlayer?.let { mp ->
            try {
                if (mp.isPlaying) {
                    mp.stop()
                }
                mp.reset()
                mp.release()
            } catch (e: Exception) {
                Log.w(TAG, "Error releasing MediaPlayer: ${e.message}")
            }
        }
        mediaPlayer = null
    }

    private fun updateState(newState: AudioPlaybackState, errorMessage: String?) {
        _currentState = newState
        listener?.invoke(newState, errorMessage)
    }
}
