PALASH 🌸

Offline-First Multilingual Learning Assistant

Overview

PALASH is an offline-first educational learning system that combines
structured educational content, multilingual support, Santali/Ol Chiki
learning text, audio resources, local storage, and a native Android
application.

Home
↓
Select Grade
↓
Subject / Topic
↓
Bilingual Educational Content
↓
Santali / Ol Chiki Support
↓
Audio Playback
↓
Worksheet
↓
Flashcards
↓
Practice / Assessment

Problem

PALASH addresses teacher--student language mismatch, limited digital
resources for tribal and low-resource languages, unreliable
connectivity, and the need for structured bilingual learning resources.

Solution

Educational Content
+
Translation / Language Support
+
Speech and Audio
+
Backend and Data Services
+
Offline Content Storage
+
Native Android Application
↓
ONE PALASH LEARNING EXPERIENCE

The project supports grade-based learning, foundational mathematics,
Hindi content, Santali/Ol Chiki support where supplied, reusable audio,
lessons, worksheets, flashcards, and practice content.

Team Architecture

M1 --- Backend and Data Services

Backend, data handling, and application data-flow support.

M2 --- Translation and Language Technology

Multilingual and education-focused language technology support.

M3 --- Speech and Audio

Speech/audio resources used by educational content.

M4 --- Native Android Application

Current architecture:

M1 Backend
+
Room Local Database
+
Versioned Content Pack
+
Native Compose UI
+
Native Android Audio Playback
+
Offline-First Storage

M5 --- Educational Content

M5 provides Grade 2 and Grade 3 lessons, worksheets, flashcards,
assessments, structured JSON data, supporting metadata, audio mapping
support, Python reference files, HTML reference outputs, and
documentation.

M6 --- UI/UX, QA, Presentation and Demo Support

Supports product presentation, QA, screenshots, UI/UX coordination, and
demo preparation.

M5 Handoff Structure

M5_handover/
├── audio/
├── data/
├── output/
├── src/
└── README.md

data/

Contains machine-readable educational content for:

Grade 2 lessons, worksheets, flashcards, and assessments

Grade 3 lessons, worksheets, flashcards, and assessments

supporting CSV/metadata where available

General model:

Grade
↓
Subject
↓
Topic
↓
Lesson / Learning Unit
↓
Sections / Cards / Questions
↓
Hindi Content
+
Santali / Ol Chiki Content
+
Visual Content
+
Audio Reference

Typical fields include grade, subject, topic, lesson ID, section ID,
card ID, question ID, title, Hindi text, Santali text, visuals, answer
data, audio references, learning objectives, and expected learning
outcomes.

Grade 2 Content

Grade 2 is the first integration target:

Grade 2
↓
Mathematics
↓
Counting
↓
Lesson
↓
Santali / Ol Chiki Support
↓
Audio
↓
Worksheet
↓
Flashcards

The content supports number recognition, object counting, number
vocabulary, examples, student activities, and foundational numeracy
practice.

Grade 2 Lesson 2 Audio

Section mapping:

SEC01 → L2_SEC01.wav
SEC02 → L2_SEC02.wav
SEC03 → L2_SEC03.wav
SEC04 → L2_SEC04.wav
SEC05 → L2_SEC05.wav
SEC06 → L2_SEC06.wav

Integration rule:

Section ID
↓
Audio Reference
↓
Exact Filename
↓
Actual Audio Asset
↓
Native Android Playback

Existing content IDs and audio filenames should be preserved.

Reusable Number Audio

numbers/
├── number_1.wav
├── number_2.wav
├── ...
└── number_10.wav

Example:

1 → number_1.wav
5 → number_5.wav
10 → number_10.wav

This avoids unnecessary duplication across lessons and flashcards.

Grade 3 Content

Grade 3 resources are included for audit and subsequent integration.
Available categories include lessons, flashcards, worksheets,
assessments, and associated audio assets. The immediate priority is a
stable Grade 2 vertical slice.

Audio Structure

Typical categories:

audio/
└── santali_audio/
    ├── lesson_g2/
    ├── numbers/
    ├── worksheet/
    ├── flashcards/
    ├── assessment/
    ├── lesson_g3/
    ├── worksheet_g3/
    ├── flashcards_g3/
    └── assessment_g3/

The actual handoff folders and filenames are used as the integration
source.

Every audio-enabled item should be traceable through:

Content ID
+
Expected Audio Filename
+
Actual Audio File
+
Android Mapping

src/ --- Python Content Pipeline

The Python reference pipeline follows:

Structured JSON
↓
Python Processing
↓
Generated Educational Interface
↓
Reference HTML Output

It supports lessons, flashcards, worksheets, assessments, visual
content, and audio mapping. Android integration uses the native M4
architecture rather than executing Python directly.

output/ --- HTML Reference Outputs

HTML outputs demonstrate lesson presentation, Hindi content, Santali/Ol
Chiki content, visual learning elements, flashcards, worksheets,
assessments, and audio controls.

The main Android integration remains:

M5 Content
↓
M4 Validation and Mapping
↓
Versioned Content Pack
↓
Room / Local Storage
↓
Native Compose UI
↓
Native Android Audio Playback

Integration Architecture

M5 JSON / Structured Content
+
Existing Content IDs
+
Existing Audio Assets
↓
M4 Integration Audit
↓
Android Content Mapping
↓
Versioned Content Pack
↓
Room / Local Storage
↓
Native Compose UI
↓
Native Android Audio Playback

First Product Vertical Slice

Home
↓
Grade 2
↓
Mathematics
↓
Counting
↓
Educational Lesson
↓
Hindi + Santali / Ol Chiki Content
↓
Correct Audio Playback
↓
Worksheet
↓
Flashcards

Offline-First Design

Content Pack
↓
Local Device Storage
↓
Room / Local Data Access
↓
Native Content Rendering
↓
Local Audio Playback

Integration Rules

Preserve existing content IDs.

Preserve lesson, section, card, and question identifiers.

Preserve audio filenames.

Keep references synchronized with actual file locations.

Avoid unnecessary duplicate audio.

Keep Grade 2 and Grade 3 logically separated.

Report exact mapping conflicts before changing source data.

Preserve source and provenance metadata used by the project.

Integration Audit

Field                 Required Check

File path             Exact source location
Content type          Lesson / worksheet / flashcard / assessment
Grade                 Grade 2 or Grade 3
Lesson ID             Exact learning unit
Section ID            Exact section where applicable
Hindi content         Available for display
Santali content       Available for display
Audio reference       Filename expected by content
Actual audio file     File physically present
Android destination   Content pack / database / assets
Integration status    Pending / mapped / integrated / tested

Testing Checklist

Content

Grade selection works.

Correct lesson is displayed.

Section order is correct.

Hindi text renders correctly.

Santali / Ol Chiki text renders correctly.

Audio

Lesson audio maps correctly.

Number audio maps correctly.

Flashcard audio maps correctly.

Worksheet audio maps correctly where included.

Assessment audio maps correctly where included.

Data

JSON parses successfully.

Required fields are present.

IDs are consistent.

Audio references resolve to actual files.

Android

Native Compose UI displays content.

Room/local content access works.

Native audio playback works.

Core offline content flow works as implemented.

Navigation between learning components works.

Demo Flow

1. Open PALASH
2. Select Grade 2
3. Open Mathematics
4. Open Counting
5. Display educational content
6. Show Santali / Ol Chiki support
7. Play mapped audio
8. Demonstrate number learning
9. Open a worksheet
10. Open flashcards
11. Demonstrate local/offline content access

Current Project Work

The M5 handoff package contains structured educational data, Grade 2
resources, Grade 3 resources, lessons, worksheets, flashcards,
assessments, Santali audio assets, reusable number audio, Python
reference files, HTML reference outputs, and documentation.

The main remaining engineering work is system integration and end-to-end
QA.

Remaining Priorities

P0 --- Grade 2 Native Vertical Slice

Home
↓
Grade 2
↓
Mathematics
↓
Counting
↓
Lesson
↓
Audio
↓
Worksheet
↓
Flashcards

P1 --- Audio Mapping Verification

Content Reference
=
Expected Filename
=
Actual Audio Asset
=
Android Playback Mapping

P1 --- Grade 3 Integration

Integrate Grade 3 after the Grade 2 flow is stable.

P2 --- Assessment Integration

Integrate assessments according to the Android data model without
compromising the core learning flow.

Final Team Goal

M1
+
M2
+
M3
+
M4
+
M5
+
M6
↓
ONE STABLE PALASH ANDROID PRODUCT

Final Principle

A small, stable, integrated learning experience is more valuable
than a large collection of disconnected features.

PALASH brings together:

Educational Content
+
Language Support
+
Audio
+
Offline Storage
+
Native Android UI

into one coherent learning experience.

Final Status

M5 Educational Content Package: Prepared for integration.

Primary Integration Target: Grade 2 Mathematics --- Counting.

Secondary Content: Grade 3 resources included for audit and
subsequent integration.

Android Architecture: Native Compose + Room/local content
architecture + native audio playback.

Project Goal: One stable, offline-first PALASH Android learning
experience.