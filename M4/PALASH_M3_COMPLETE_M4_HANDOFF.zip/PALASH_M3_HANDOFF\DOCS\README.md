# PALASH — M3 Technical Notes & Judge Preparation Cheat Sheet

## Overview

PALASH is an AI-powered educational platform designed to support tribal and multilingual learners through:

- Speech-to-Text (ASR)
- Hindi → Santali Translation
- Santali Audio Output
- Educational Audio Assets
- Offline-first Architecture

My responsibility (M3) was the complete speech and audio pipeline.

---

# M3 Contribution Summary

I completed:

1. Hindi Speech Recognition (ASR)
2. Hindi → Santali Translation Integration
3. Santali Romanization Layer
4. Santali Speech Output (TTS)
5. Educational Audio Asset Generation
6. Audio Inventory Creation
7. Audio Manifest Creation
8. Android Audio Handoff Package
9. Grade 2 Lesson Audio Generation
10. Playback Verification

---

# End-to-End Pipeline

User Speaks Hindi

↓

Audio Recording

↓

Whisper ASR

↓

Hindi Text

↓

Translation Service

↓

Santali Text (Ol Chiki)

↓

Romanization Layer

↓

pyttsx3 TTS

↓

Santali Audio Output

---

# Speech Recognition (ASR)

## Technology Used

Faster-Whisper

Model:

small

## Why Faster Whisper

- Offline
- Lightweight
- Faster than original Whisper
- Suitable for CPU execution
- Good Hindi support

## Input

Hindi Speech

## Output

Hindi Text

Example:

Hindi Speech:

"मेरा नाम राहुल है"

↓

Hindi Text:

"मेरा नाम राहुल है"

---

# Translation Layer

## Translation Direction

Hindi (Devanagari)

↓

Santali (Ol Chiki)

## Translation Service

translation_service.py

## Input

Hindi Text

## Output

Santali Text

Example:

Hindi:

मेरा नाम राहुल है

↓

Santali:

ᱤᱧ ᱧᱩᱛᱩᱢ ᱨᱟᱦᱩᱞ ᱠᱟᱱᱟ

---

# Romanization Layer

## Why Romanization?

Windows TTS engines cannot reliably speak Ol Chiki script.

Therefore:

Ol Chiki

↓

Romanized Santali

↓

TTS Engine

Example:

ᱢᱤᱫ

↓

mit

Example:

ᱵᱟᱨ

↓

bar

Example:

ᱢᱚᱨᱟᱭ

↓

morae

---

# Romanization Mapping

Examples:

᱑ → mit

᱒ → bar

᱓ → pe

᱔ → pon

᱕ → morae

᱖ → turui

᱗ → eyae

᱘ → iral

᱙ → are

---

# Text-to-Speech (TTS)

## Technology

pyttsx3

## Why pyttsx3

- Offline
- No API costs
- Runs locally
- Fast integration
- Suitable for MVP

## Process

Romanized Santali

↓

pyttsx3

↓

WAV Output

↓

Playback

---

# Educational Audio Generation

Audio generated using:

pyttsx3

Generation scripts created for:

## Numbers

number_1.wav

to

number_20.wav

## Worksheet Audio

WSQ001

to

WSQ005

## Flashcards

FC001

to

FC014

(selected assets)

## Assessments

AS001

to

AS005

## Grade 3 Content

worksheet_g3

flashcards_g3

assessment_g3

lesson_g3

---

# Audio Asset Statistics

Total WAV Files:

70

Categories:

- numbers = 20
- worksheet = 5
- flashcards = 7
- assessment = 5
- worksheet_g3 = 6
- flashcards_g3 = 20
- assessment_g3 = 6
- lesson_g3 = 1

Total = 70

---

# Audio Specifications

Measured Properties:

Sample Rate:

22050 Hz

Channels:

1 (Mono)

Bit Depth:

16-bit

Format:

WAV

---

# Audio Inventory

Created:

audio_inventory.csv

Contains:

- filename
- relative_path
- sample_rate
- channels
- bit_depth
- duration
- size
- sha256 checksum

Purpose:

Technical verification and Android handoff.

---

# Audio Manifest

Created:

audio_manifest.csv

Contains:

- Audio ID
- Category
- Grade
- Text Mapping
- Metadata
- Checksums
- Validation Status

Validation Status:

NATIVE_SPEAKER_VALIDATED

Audio assets were reviewed and validated with a native Santali speaker during project development.

The validation confirmed:
- Pronunciation acceptability
- Vocabulary correctness for the generated content
- Educational usability for the current MVP

This validation applies to the audio assets currently included in the PALASH M3 deliverables.
---

# Android Audio Handoff

Created:

PALASH_M3_M4_CORRECTED_HANDOFF.zip

Contains:

- live_pipeline.py
- translation_service.py
- audio_inventory.csv
- audio_manifest.csv
- all 70 WAV files

Purpose:

Direct Android integration by M4.

---

# Grade 2 Lesson Audio Work

Generated:

lesson_g2/

Files:

L2_SEC01.wav

L2_SEC02.wav

L2_SEC03.wav

L2_SEC04.wav

L2_SEC05.wav

L2_SEC06.wav

Purpose:

Grade 2 Mathematics Counting Lesson.

---

# Android Playback Verification

Playback tested manually.

Files opened successfully.

No playback errors observed.

Result:

Android Compatibility:

TESTED SUCCESSFULLY FOR WAV PLAYBACK

---

# Offline Architecture

Current PALASH MVP is offline-first.

Advantages:

- Works without internet
- Low latency
- No cloud dependency
- Suitable for rural deployment
- Privacy-friendly

---

# Future Hybrid Architecture

Possible future design:

Mode 1:

Offline

Whisper + Translation Service + pyttsx3

Mode 2:

Online

Cloud ASR

↓

Cloud Translation

↓

Cloud TTS

Automatic switching based on internet availability.

This is future scope.

Not implemented in current MVP.

---

# Libraries Used

Python

Faster Whisper

pyttsx3

sounddevice

scipy

winsound

os

sys

time

---

# Key Technical Decisions

1. Offline-first architecture
2. Faster Whisper for ASR
3. Romanization before TTS
4. pyttsx3 for offline speech synthesis
5. WAV format for Android compatibility
6. Manifest-based audio tracking
7. Checksum-based verification

---

# M3 Judge Cheat Sheet

## My Role

Speech and Audio Pipeline Engineer

---

## ASR

Faster Whisper

Offline

Hindi Speech → Hindi Text

---

## Translation

Hindi → Santali

Ol Chiki Output

---

## TTS

Romanized Santali

↓

pyttsx3

↓

WAV Audio

---

## Audio Assets Created

70 WAV Files

---

## Audio Metadata

22050 Hz

Mono

16-bit WAV

---

## Manifest

audio_inventory.csv

audio_manifest.csv

---

## Android Handoff

PALASH_M3_M4_CORRECTED_HANDOFF.zip

---

## Validation Status

NATIVE_SPEAKER_VALIDATED

Current Santali audio assets were validated with a native Santali speaker.

Status:
VALIDATED
---

## Biggest Technical Challenge

Ol Chiki script is not reliably supported by standard Windows TTS engines.

Solution:

Ol Chiki

↓

Romanized Santali

↓

pyttsx3

↓

Audio Output

---

## Future Improvements

- Native Santali TTS
- Larger-scale speaker validation across multiple dialect groups
- Online Hybrid Mode
- Better ASR Models
- Improved Translation Accuracy

---

# Final M3 Contribution

Delivered:

✓ Offline Speech Pipeline

✓ Translation Integration

✓ Romanization Layer

✓ Santali Audio Output

✓ Educational Audio Assets

✓ Inventory & Manifest

✓ Android Handoff Package

✓ Grade 2 Lesson Audio

✓ Playback Verification

Status:

M3 WORK COMPLETED