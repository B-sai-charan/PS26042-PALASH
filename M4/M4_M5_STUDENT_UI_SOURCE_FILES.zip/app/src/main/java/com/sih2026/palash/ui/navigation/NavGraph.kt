package com.sih2026.palash.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sih2026.palash.data.config.AppConfigManager
import com.sih2026.palash.model.DeviceRole
import com.sih2026.palash.ui.screens.flashcard.FlashcardScreen
import com.sih2026.palash.ui.screens.grade.GradeSelectionScreen
import com.sih2026.palash.ui.screens.home.HomeScreen
import com.sih2026.palash.ui.screens.lesson.LessonScreen
import com.sih2026.palash.ui.screens.pack.LanguagePackScreen
import com.sih2026.palash.ui.screens.result.TranslationResultScreen
import com.sih2026.palash.ui.screens.role.RoleSelectionScreen
import com.sih2026.palash.ui.screens.role.StudentSetupScreen
import com.sih2026.palash.ui.screens.role.TeacherPinScreen
import com.sih2026.palash.ui.screens.student.StudentHomeScreen
import com.sih2026.palash.ui.screens.subject.SubjectTopicScreen
import com.sih2026.palash.ui.screens.voice.VoiceTranslationScreen
import com.sih2026.palash.ui.screens.worksheet.WorksheetScreen

object Routes {
    const val ROLE_SELECTION = "role_selection"
    const val TEACHER_PIN = "teacher_pin"
    const val STUDENT_SETUP = "student_setup"
    const val STUDENT_HOME = "student_home"
    const val HOME = "home"
    const val GRADE_SELECTION = "grade_selection"
    const val SUBJECT_SELECTION = "subject_selection/{gradeName}"
    const val LESSON = "lesson/{gradeName}/{subjectName}/{topicName}"
    const val VOICE_TRANSLATION = "voice_translation/{gradeName}/{subjectName}/{topicName}"
    const val TRANSLATION_RESULT = "translation_result?hindi={hindi}&santaliNotice={santaliNotice}"
    const val WORKSHEET = "worksheet"
    const val FLASHCARD = "flashcard"
    const val LANGUAGE_PACK = "language_pack"

    fun buildSubjectRoute(gradeName: String) =
        "subject_selection/${Uri.encode(gradeName)}"

    fun buildLessonRoute(gradeName: String, subjectName: String, topicName: String) =
        "lesson/${Uri.encode(gradeName)}/${Uri.encode(subjectName)}/${Uri.encode(topicName)}"

    fun buildVoiceRoute(gradeName: String, subjectName: String, topicName: String) =
        "voice_translation/${Uri.encode(gradeName)}/${Uri.encode(subjectName)}/${Uri.encode(topicName)}"

    fun buildResultRoute(hindi: String, santaliNotice: String) =
        "translation_result?hindi=${Uri.encode(hindi)}&santaliNotice=${Uri.encode(santaliNotice)}"
}

@Composable
fun PalashNavHost(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    val context = LocalContext.current
    val configManager = remember { AppConfigManager(context) }

    val initialDestination = remember(configManager.isConfigured) {
        if (configManager.isConfigured) {
            when (configManager.getDeviceRole()) {
                DeviceRole.STUDENT -> Routes.STUDENT_HOME
                DeviceRole.TEACHER -> Routes.HOME
                null -> Routes.ROLE_SELECTION
            }
        } else {
            Routes.ROLE_SELECTION
        }
    }

    NavHost(
        navController = navController,
        startDestination = initialDestination,
        modifier = modifier
    ) {
        composable(Routes.ROLE_SELECTION) {
            RoleSelectionScreen(
                onSelectTeacher = {
                    navController.navigate(Routes.TEACHER_PIN)
                },
                onSelectStudent = {
                    navController.navigate(Routes.STUDENT_SETUP)
                }
            )
        }

        composable(Routes.TEACHER_PIN) {
            TeacherPinScreen(
                onPinVerified = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ROLE_SELECTION) { inclusive = true }
                    }
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.STUDENT_SETUP) {
            StudentSetupScreen(
                onSetupComplete = {
                    navController.navigate(Routes.STUDENT_HOME) {
                        popUpTo(Routes.ROLE_SELECTION) { inclusive = true }
                    }
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.STUDENT_HOME) {
            StudentHomeScreen(
                onReconfigure = {
                    navController.navigate(Routes.ROLE_SELECTION) {
                        popUpTo(Routes.STUDENT_HOME) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.HOME) {
            HomeScreen(
                onStartLesson = {
                    navController.navigate(Routes.GRADE_SELECTION)
                },
                onManagePacks = {
                    navController.navigate(Routes.LANGUAGE_PACK)
                }
            )
        }

        composable(Routes.LANGUAGE_PACK) {
            LanguagePackScreen(
                onBackToHome = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.GRADE_SELECTION) {
            GradeSelectionScreen(
                onContinue = { selectedGrade ->
                    navController.navigate(Routes.buildSubjectRoute(selectedGrade))
                }
            )
        }

        composable(
            route = Routes.SUBJECT_SELECTION,
            arguments = listOf(navArgument("gradeName") { type = NavType.StringType })
        ) { backStackEntry ->
            val gradeName = backStackEntry.arguments?.getString("gradeName") ?: "Grade 2"
            SubjectTopicScreen(
                gradeName = gradeName,
                onStartClassroom = { subject, topic ->
                    navController.navigate(Routes.buildLessonRoute(gradeName, subject, topic))
                }
            )
        }

        composable(
            route = Routes.LESSON,
            arguments = listOf(
                navArgument("gradeName") { type = NavType.StringType },
                navArgument("subjectName") { type = NavType.StringType },
                navArgument("topicName") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val gradeName = backStackEntry.arguments?.getString("gradeName") ?: "Grade 2"
            val subjectName = backStackEntry.arguments?.getString("subjectName") ?: "Mathematics"
            val topicName = backStackEntry.arguments?.getString("topicName") ?: "Counting"

            LessonScreen(
                gradeName = gradeName,
                subjectName = subjectName,
                topicName = topicName,
                onOpenWorksheet = {
                    navController.navigate(Routes.WORKSHEET)
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Routes.VOICE_TRANSLATION,
            arguments = listOf(
                navArgument("gradeName") { type = NavType.StringType },
                navArgument("subjectName") { type = NavType.StringType },
                navArgument("topicName") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val gradeName = backStackEntry.arguments?.getString("gradeName") ?: "Grade 2"
            val subjectName = backStackEntry.arguments?.getString("subjectName") ?: "Mathematics"
            val topicName = backStackEntry.arguments?.getString("topicName") ?: "Counting"

            VoiceTranslationScreen(
                grade = gradeName,
                subject = subjectName,
                topic = topicName,
                onViewResult = { hindi, santaliNotice ->
                    navController.navigate(Routes.buildResultRoute(hindi, santaliNotice))
                }
            )
        }

        composable(
            route = Routes.TRANSLATION_RESULT,
            arguments = listOf(
                navArgument("hindi") {
                    type = NavType.StringType
                    defaultValue = "पाँच आम गिनो।"
                },
                navArgument("santaliNotice") {
                    type = NavType.StringType
                    defaultValue = "Sample translation — pending language validation"
                }
            )
        ) { backStackEntry ->
            val hindi = backStackEntry.arguments?.getString("hindi") ?: "पाँच आम गिनो।"
            val santaliNotice = backStackEntry.arguments?.getString("santaliNotice") ?: "Sample translation — pending language validation"

            TranslationResultScreen(
                hindiText = hindi,
                santaliNotice = santaliNotice,
                onOpenWorksheet = {
                    navController.navigate(Routes.WORKSHEET)
                },
                onBackToClassroom = {
                    navController.popBackStack(Routes.GRADE_SELECTION, inclusive = false)
                }
            )
        }

        composable(Routes.WORKSHEET) {
            WorksheetScreen(
                onBackToClassroom = {
                    navController.popBackStack(Routes.GRADE_SELECTION, inclusive = false)
                },
                onOpenFlashcards = {
                    navController.navigate(Routes.FLASHCARD)
                }
            )
        }

        composable(Routes.FLASHCARD) {
            FlashcardScreen(
                onBackToClassroom = {
                    navController.popBackStack(Routes.GRADE_SELECTION, inclusive = false)
                }
            )
        }
    }
}
