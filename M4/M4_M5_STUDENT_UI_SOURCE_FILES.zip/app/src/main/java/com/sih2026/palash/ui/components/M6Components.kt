package com.sih2026.palash.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sih2026.palash.ui.theme.Grade1Color
import com.sih2026.palash.ui.theme.Grade2Color
import com.sih2026.palash.ui.theme.Grade3Color
import com.sih2026.palash.ui.theme.KeypadBg
import com.sih2026.palash.ui.theme.PalashTerracotta
import com.sih2026.palash.ui.theme.StudentOrange
import com.sih2026.palash.ui.theme.StudentOrangeBorder
import com.sih2026.palash.ui.theme.StudentOrangeContainer
import com.sih2026.palash.ui.theme.TeacherGreen
import com.sih2026.palash.ui.theme.TeacherGreenBorder
import com.sih2026.palash.ui.theme.TeacherGreenContainer

/**
 * Top M6 Brand Header Component with Logo Emblem, Devanagari & Ol Chiki Title, and Offline Badge.
 */
@Composable
fun PalashBrandHeader(
    modifier: Modifier = Modifier,
    showOfflineBadge: Boolean = true,
    subtitle: String? = "भाषाओं को जोड़ें, सीखने का उजाला फैलाएं"
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showOfflineBadge) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFFFF3E0),
                    border = BorderStroke(1.dp, Color(0xFFFFCC80))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "📡", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ऑफ़लाइन काम करता है",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD84315)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Emblem & Title
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                shape = CircleShape,
                color = PalashTerracotta.copy(alpha = 0.1f),
                modifier = Modifier.size(64.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(text = "🌺", fontSize = 32.sp)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "पलाश",
                fontSize = 34.sp,
                fontWeight = FontWeight.Black,
                color = PalashTerracotta,
                letterSpacing = 1.sp
            )

            Text(
                text = "ᱯᱚᱞᱟᱥ",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF795548)
            )

            if (!subtitle.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(1.dp)
                            .background(Color(0xFFE0E0E0))
                    )
                    Text(
                        text = subtitle,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF5D4037),
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(1.dp)
                            .background(Color(0xFFE0E0E0))
                    )
                }
            }
        }
    }
}

/**
 * Reusable M6 Role Selection Card (Student vs Teacher).
 */
@Composable
fun M6RoleCard(
    roleTitle: String,
    olChikiSubtitle: String,
    isTeacher: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerBg = if (isTeacher) TeacherGreenContainer else StudentOrangeContainer
    val borderColor = if (isTeacher) TeacherGreenBorder else StudentOrangeBorder
    val buttonBg = if (isTeacher) TeacherGreen else StudentOrange
    val iconEmoji = if (isTeacher) "👩‍🏫" else "🧑‍🎓"

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = containerBg),
        border = BorderStroke(2.dp, borderColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = iconEmoji, fontSize = 64.sp)

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                color = buttonBg
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = roleTitle,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = olChikiSubtitle,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Reusable M6 Grade Card component (Grade 1, Grade 2, Grade 3).
 */
@Composable
fun M6GradeCard(
    gradeNumber: Int,
    devanagariTitle: String,
    olChikiTitle: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cardBg = when (gradeNumber) {
        1 -> Grade1Color
        2 -> Grade2Color
        3 -> Grade3Color
        else -> Grade2Color
    }

    val digitDevanagari = when (gradeNumber) {
        1 -> "१"
        2 -> "२"
        3 -> "३"
        else -> "$gradeNumber"
    }

    val digitOlChiki = when (gradeNumber) {
        1 -> "᱑"
        2 -> "᱒"
        3 -> "᱓"
        else -> "$gradeNumber"
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 8.dp else 2.dp),
        border = if (isSelected) BorderStroke(3.dp, Color.White) else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = devanagariTitle,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = olChikiTitle,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.9f)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = digitDevanagari,
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = digitOlChiki,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.9f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = subtitle,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Reusable M6 Teacher PIN Keypad Component.
 */
@Composable
fun M6PinKeypad(
    pinLength: Int,
    maxPinLength: Int = 4,
    onDigitClick: (String) -> Unit,
    onBackspaceClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // PIN Dot Indicators
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 0 until maxPinLength) {
                val filled = i < pinLength
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (filled) PalashTerracotta else Color.Transparent)
                        .background(if (!filled) Color.White.copy(alpha = 0.5f) else PalashTerracotta)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // 3x4 Numeric Keypad
        val keys = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "BACKSPACE")
        )

        keys.forEach { row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row.forEach { key ->
                    if (key.isEmpty()) {
                        Spacer(modifier = Modifier.size(72.dp))
                    } else if (key == "BACKSPACE") {
                        Surface(
                            modifier = Modifier
                                .size(72.dp)
                                .clickable { onBackspaceClick() },
                            shape = CircleShape,
                            color = KeypadBg.copy(alpha = 0.7f)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Backspace",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    } else {
                        Surface(
                            modifier = Modifier
                                .size(72.dp)
                                .clickable { onDigitClick(key) },
                            shape = CircleShape,
                            color = KeypadBg
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = key,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Concise Provenance Warning Badge for M5 Content.
 */
@Composable
fun M6UnverifiedBadge(
    modifier: Modifier = Modifier,
    text: String = "⚠️ Unverified content"
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFFFF3E0),
        border = BorderStroke(1.dp, Color(0xFFFFB74D))
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE65100),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
