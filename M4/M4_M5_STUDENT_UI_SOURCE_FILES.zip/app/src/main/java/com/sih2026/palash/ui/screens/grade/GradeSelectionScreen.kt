package com.sih2026.palash.ui.screens.grade

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sih2026.palash.R
import com.sih2026.palash.ui.components.M6GradeCard
import com.sih2026.palash.ui.components.PalashBrandHeader
import com.sih2026.palash.ui.localization.teacherStringResource

@Composable
fun GradeSelectionScreen(
    onContinue: (selectedGradeName: String) -> Unit,
    viewModel: GradeSelectionViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState)
            ) {
                PalashBrandHeader(showOfflineBadge = true)

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = teacherStringResource(R.string.grade_title),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = teacherStringResource(R.string.grade_subtitle),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    M6GradeCard(
                        gradeNumber = 1,
                        devanagariTitle = teacherStringResource(R.string.grade_1_name),
                        olChikiTitle = "ᱪᱟᱱᱟᱪ ᱑",
                        subtitle = teacherStringResource(R.string.grade_1_desc),
                        isSelected = uiState.selectedGradeId == "grade_1",
                        onClick = { viewModel.selectGrade("grade_1") },
                        modifier = Modifier.weight(1f)
                    )

                    M6GradeCard(
                        gradeNumber = 2,
                        devanagariTitle = teacherStringResource(R.string.grade_2_name),
                        olChikiTitle = "ᱪᱟᱱᱟᱪ ᱒",
                        subtitle = teacherStringResource(R.string.grade_2_desc),
                        isSelected = uiState.selectedGradeId == "grade_2",
                        onClick = { viewModel.selectGrade("grade_2") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                M6GradeCard(
                    gradeNumber = 3,
                    devanagariTitle = teacherStringResource(R.string.grade_3_name),
                    olChikiTitle = "ᱪᱟᱱᱟᱪ ᱓",
                    subtitle = teacherStringResource(R.string.grade_3_desc),
                    isSelected = uiState.selectedGradeId == "grade_3",
                    onClick = { viewModel.selectGrade("grade_3") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Button(
                onClick = {
                    val selectedGradeName = when (uiState.selectedGradeId) {
                        "grade_1" -> "Grade 1"
                        "grade_2" -> "Grade 2"
                        "grade_3" -> "Grade 3"
                        else -> "Grade 2"
                    }
                    onContinue(selectedGradeName)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = teacherStringResource(R.string.grade_continue),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
